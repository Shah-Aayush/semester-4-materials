function validateForm() {

    var owner_name = document.getElementById("owner_name");
    var check_owner = /^[a-z]+$/i;
    var email = document.getElementById("email");
    var check_email = /\S+@\S+\.\S+/;

    if(owner_name.value.trim() == ''){
        alert("Empty name.");
        owner_name.style.border = "solid 2px red";
        return false;
    }
    else if (!check_owner.test(owner_name.value)) {
        alert("Only Alphabets allowed in owner name.");
        owner_name.style.border = "solid 2px red";
        return false;
    }
    else if (owner_name.value.length<30) {
        alert("Owner name should be more than 30.");
        owner_name.style.border = "solid 2px red";
        return false;
    }
    else if (email.value == "" || !check_email.test(email.value)) {
        alert("Please enter valid email address [valid format is : DDCCCDD@nirmauni.ac.in]");
        email.style.border = "solid 2px red";
        return false;
    }
    else {
        owner_name.style.border = "solid 2px blue";
        email.style.border = "solid 2px blue";
        return true;
    }
}