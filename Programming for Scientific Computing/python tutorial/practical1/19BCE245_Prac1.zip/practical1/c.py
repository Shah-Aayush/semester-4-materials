intType = int(input("Enter int type data : "))
print("Int Type\t\tFloat Type\t\tString Type\t")
print(intType,"\t\t\t", float(intType), "\t\t\t", str(intType))

floatType = float(input("Enter float type data : "))
print("Int Type\tFloat Type\tString Type\t")
print(int(floatType),"\t\t\t", floatType, "\t\t\t", str(floatType))

stringType = input("Enter String type data : ")
print("Int Type\t\tFloat Type\t\tString Type\t")
print(int(stringType),"\t\t\t", float(stringType), "\t\t\t", stringType)